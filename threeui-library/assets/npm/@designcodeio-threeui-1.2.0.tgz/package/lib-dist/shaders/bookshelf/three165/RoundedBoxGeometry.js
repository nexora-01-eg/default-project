import { BoxGeometry as p, Vector3 as f } from "three165";
const M = new f();
function s(u, y, x, b, c, o) {
  const z = 2 * Math.PI * c / 4, i = Math.max(o - 2 * c, 0), t = Math.PI / 4;
  M.copy(y), M[b] = 0, M.normalize();
  const m = 0.5 * z / (z + i), l = 1 - M.angleTo(u) / t;
  return Math.sign(M[x]) === 1 ? l * m : i / (z + i) + m + m * (1 - l);
}
class g extends p {
  constructor(y = 1, x = 1, b = 1, c = 2, o = 0.1) {
    if (c = c * 2 + 1, o = Math.min(y / 2, x / 2, b / 2, o), super(1, 1, 1, c, c, c), c === 1) return;
    const z = this.toNonIndexed();
    this.index = null, this.attributes.position = z.attributes.position, this.attributes.normal = z.attributes.normal, this.attributes.uv = z.attributes.uv;
    const i = new f(), t = new f(), m = new f(y, x, b).divideScalar(2).subScalar(o), l = this.attributes.position.array, v = this.attributes.normal.array, a = this.attributes.uv.array, k = l.length / 6, n = new f(), h = 0.5 / c;
    for (let r = 0, e = 0; r < l.length; r += 3, e += 2)
      switch (i.fromArray(l, r), t.copy(i), t.x -= Math.sign(t.x) * h, t.y -= Math.sign(t.y) * h, t.z -= Math.sign(t.z) * h, t.normalize(), l[r + 0] = m.x * Math.sign(i.x) + t.x * o, l[r + 1] = m.y * Math.sign(i.y) + t.y * o, l[r + 2] = m.z * Math.sign(i.z) + t.z * o, v[r + 0] = t.x, v[r + 1] = t.y, v[r + 2] = t.z, Math.floor(r / k)) {
        case 0:
          n.set(1, 0, 0), a[e + 0] = s(n, t, "z", "y", o, b), a[e + 1] = 1 - s(n, t, "y", "z", o, x);
          break;
        case 1:
          n.set(-1, 0, 0), a[e + 0] = 1 - s(n, t, "z", "y", o, b), a[e + 1] = 1 - s(n, t, "y", "z", o, x);
          break;
        case 2:
          n.set(0, 1, 0), a[e + 0] = 1 - s(n, t, "x", "z", o, y), a[e + 1] = s(n, t, "z", "x", o, b);
          break;
        case 3:
          n.set(0, -1, 0), a[e + 0] = 1 - s(n, t, "x", "z", o, y), a[e + 1] = 1 - s(n, t, "z", "x", o, b);
          break;
        case 4:
          n.set(0, 0, 1), a[e + 0] = 1 - s(n, t, "x", "y", o, y), a[e + 1] = 1 - s(n, t, "y", "x", o, x);
          break;
        case 5:
          n.set(0, 0, -1), a[e + 0] = s(n, t, "x", "y", o, y), a[e + 1] = 1 - s(n, t, "y", "x", o, x);
          break;
      }
  }
}
const B = g;
export {
  B as RoundedBoxGeometry
};
