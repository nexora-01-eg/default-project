const t = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Meng To</title>
<meta name="description" content="designer, creator, AI educator — Singapore">
<style>
@font-face{font-family:'Instrument Serif';font-style:normal;font-weight:400;font-display:block;
  src:url(sketchbook/instrument-serif.woff2) format('woff2')}
@font-face{font-family:'Instrument Serif';font-style:italic;font-weight:400;font-display:block;
  src:url(sketchbook/instrument-serif-italic.woff2) format('woff2')}
@font-face{font-family:'Newsreader';font-style:normal;font-weight:200 600;font-display:swap;
  src:url(sketchbook/newsreader.woff2) format('woff2')}

:root{
  --paper:#ece7dc;
  --ink:#2b2721;
  --ink-soft:rgba(43,39,33,.58);
  --ink-faint:rgba(43,39,33,.36);
  --hairline:rgba(43,39,33,.14);
  --earth:#9a6a3e;
  --display:'Instrument Serif',"New York",Georgia,'Times New Roman',serif;
  --font:'Newsreader',"New York",Georgia,'Times New Roman',serif;
  --track-caps:.24em;
  --track-nav:.06em;
}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
html{-webkit-text-size-adjust:100%}
body{
  font-family:var(--font);font-weight:400;background:var(--paper);color:var(--ink);
  -webkit-font-smoothing:antialiased;overflow-x:hidden;
}
a{color:inherit;text-decoration:none}
button{font:inherit}
::selection{background:rgba(43,39,33,.85);color:var(--paper)}

/* the painted ground the whole page sits on */
.wash{
  position:fixed;inset:0;z-index:-2;pointer-events:none;
  background:url(sketchbook/bg-wash.jpg) center top / cover no-repeat;
  opacity:.85;
}
.wash:after{
  content:"";position:absolute;inset:0;
  background:linear-gradient(180deg,rgba(236,231,220,.25) 0%,rgba(236,231,220,.72) 58%,var(--paper) 88%);
}

/* ---------------- top bar ---------------- */
.top{
  position:fixed;top:0;left:0;right:0;z-index:500;
  display:flex;flex-direction:column;align-items:center;gap:11px;
  padding-inline:clamp(16px,4vw,48px);padding-block:18px 64px;pointer-events:none;text-align:center;
}
.top>*{pointer-events:auto}
.top:before{
  content:"";position:absolute;inset:0;z-index:-1;
  background:linear-gradient(180deg,rgba(240,236,226,.94),rgba(240,236,226,.7) 48%,rgba(240,236,226,0));
  -webkit-backdrop-filter:blur(14px) saturate(.95);backdrop-filter:blur(14px) saturate(.95);
  -webkit-mask-image:linear-gradient(180deg,#000 46%,transparent);
  mask-image:linear-gradient(180deg,#000 46%,transparent);
}
.top .name{
  font-family:var(--display);font-size:clamp(24px,2.4vw,30px);letter-spacing:.01em;
  white-space:nowrap;line-height:1;
}
.top nav{
  display:flex;gap:clamp(14px,2vw,26px);font-size:15px;align-items:center;
  letter-spacing:var(--track-nav);font-weight:300;
}
.top nav a{color:var(--ink-soft);transition:color .2s}
.top nav a:hover,.top nav a[aria-current]{color:var(--ink)}
.top nav .top-socials{
  display:flex;align-items:center;gap:13px;margin-left:2px;padding-left:clamp(12px,1.6vw,20px);
  border-left:1px solid var(--hairline);
}
.icon-btn{display:inline-flex;align-items:center;justify-content:center;padding:4px;color:var(--ink-soft);transition:color .2s}
.icon-btn:hover{color:var(--ink)}
.top .icon-btn svg{width:16px;height:16px;display:block}
@media (max-width:640px){
  .top{padding-inline:12px;padding-block:13px 50px;gap:8px}
  .top .name{font-size:20px}
  .top nav{gap:11px;font-size:13px}
  .top nav .top-socials{gap:9px;padding-left:10px}
  .top .icon-btn{padding:2px}
  .top .icon-btn svg{width:14px;height:14px}
}

/* ---------------- hero ---------------- */
.hero{
  position:relative;display:grid;justify-items:center;align-content:center;
  min-height:100svh;overflow-anchor:none;
  padding:clamp(112px,13svh,152px) 0 clamp(72px,10svh,120px);
}
.botany{
  position:absolute;bottom:0;width:clamp(120px,15vw,250px);opacity:.5;
  pointer-events:none;user-select:none;z-index:0;
}
.botany.l{left:clamp(-40px,-1vw,0px);bottom:2%}
.botany.r{right:clamp(-30px,0vw,10px);bottom:-2%;width:clamp(100px,12vw,200px)}
@media (max-width:900px){.botany{display:none}}

.hero-kicker{
  font-size:12px;font-weight:400;letter-spacing:var(--track-caps);text-align:center;
  color:var(--ink-soft);margin:0 0 clamp(22px,3.4vh,40px);text-transform:uppercase;
}
.hero-down{
  position:absolute;bottom:30px;left:50%;transform:translateX(-50%);border:0;background:transparent;
  padding:10px 14px;color:var(--ink);cursor:pointer;-webkit-tap-highlight-color:transparent;
  animation:cue-breathe 2.6s ease-in-out infinite;z-index:3;
}
.hero-down:hover{animation:none;opacity:1}
@keyframes cue-breathe{0%,100%{opacity:.15}50%{opacity:.7}}
@media (prefers-reduced-motion:reduce){.hero-down{animation:none;opacity:.5}}

/* ---------------- sketchbook ---------------- */
.hero,.hero *{-webkit-user-select:none;-moz-user-select:none;user-select:none}
.hero img{-webkit-user-drag:none;user-drag:none}
.sb-wrap{display:grid;justify-items:center;gap:20px;width:100%;position:relative;z-index:2}
.sb-stage{
  display:flex;align-items:center;justify-content:center;width:100%;
  position:relative;
  touch-action:pan-y;
}
.sb-arrow{
  flex:none;display:inline-flex;align-items:center;justify-content:center;padding:6px 2px;
  border:0;background:transparent;color:var(--ink-faint);cursor:pointer;transition:color .2s;
  -webkit-tap-highlight-color:transparent;z-index:8;
}
.sb-arrow:hover{color:var(--ink)}

/* The box is the book's own untransformed frame: the loupe lives here, on
   the desk, while only .sb-tilt leans and scales underneath it. */
.sb-3d{
  position:relative;flex:1 1;min-width:0;max-width:900px;
  perspective:1750px;perspective-origin:50% 46%;
}
.sb-tilt{
  position:relative;
  transform-style:preserve-3d;
  transform:rotateX(var(--rx,0deg)) rotateY(var(--ry,0deg)) scale(var(--zoom,1));
  will-change:transform;
}
.sb-book{position:relative;width:100%;aspect-ratio:1760/1240;transform-style:preserve-3d;z-index:1}

/* The book sits on a surface, so its shadow is a soft pool underneath —
   no box, no filter on the artwork, nothing with an edge of its own.
   Both blobs fade to zero well inside their own bounds, and both ease
   off while a leaf is in the air. */
.sb-cast{position:absolute;pointer-events:none;z-index:0}
.sb-cast.ambient{
  left:5%;right:5%;top:27%;bottom:2%;
  background:radial-gradient(50% 50% at 50% 58%,
    rgba(58,44,26,.34) 0%,rgba(58,44,26,.19) 40%,rgba(58,44,26,0) 74%);
  filter:blur(26px);
  opacity:calc(1 - var(--shade,0) * .42);
}
.sb-cast.contact{
  left:9%;right:9%;top:62%;bottom:10%;
  background:radial-gradient(50% 44% at 50% 42%,
    rgba(44,32,14,.40) 0%,rgba(44,32,14,.17) 48%,rgba(44,32,14,0) 78%);
  filter:blur(11px);
  opacity:calc(1 - var(--shade,0) * .5);
}
.sb-cast.hair{
  left:12%;right:12%;top:70%;bottom:17%;
  background:radial-gradient(50% 52% at 50% 40%,
    rgba(40,28,10,.34) 0%,rgba(40,28,10,0) 76%);
  filter:blur(4px);
  opacity:calc(1 - var(--shade,0) * .62);
}
.sb-full{position:absolute;inset:0}
.sb-full img{width:100%;height:auto;display:block}
.sb-half{position:absolute;top:0;bottom:0;width:50%;overflow-x:clip;overflow-y:visible}
.sb-half.left{left:0}
.sb-half.right{left:50%}
.sb-half-img{width:200%;max-width:none;height:auto;display:block}
.sb-half-img.right{margin-left:-100%}
/* the shadow the lifting leaf throws onto the page beneath it */
.gutter-shade{
  position:absolute;top:var(--pg,21.8%);bottom:var(--pg,21.8%);width:46%;
  pointer-events:none;opacity:calc(var(--shade,0) * .62);
  -webkit-mask-image:linear-gradient(180deg,transparent 0,#000 5.2%,#000 94.8%,transparent 100%);
  mask-image:linear-gradient(180deg,transparent 0,#000 5.2%,#000 94.8%,transparent 100%);
}
.gutter-shade.left{right:0;background:linear-gradient(270deg,rgba(52,38,20,.30),rgba(52,38,20,0) 82%)}
.gutter-shade.right{left:0;background:linear-gradient(90deg,rgba(52,38,20,.24),rgba(52,38,20,0) 82%)}

/* ---- the turning leaf: nested strips forming a curved surface ---- */
.curl{
  position:absolute;top:0;height:100%;
  width:calc(var(--bw,0px) * var(--span));
  transform-style:preserve-3d;z-index:6;
}
.curl.next{left:50%;transform-origin:left center;transform:rotateY(calc(-1 * var(--tt,0deg)))}
.curl.prev{right:50%;transform-origin:right center;transform:rotateY(var(--tt,0deg))}
.strip{
  position:absolute;top:0;height:100%;
  width:calc(var(--bw,0px) * var(--span) / var(--n));
  transform-style:preserve-3d;
}
.curl.next .strip{transform-origin:left center}
.curl.prev .strip{transform-origin:right center}
.curl.next>.strip{left:0}
.curl.prev>.strip{right:0;left:auto}
.curl.next .strip .strip{left:100%;transform:rotateY(var(--td,0deg))}
.curl.prev .strip .strip{right:100%;transform:rotateY(calc(-1 * var(--td,0deg)))}
.face{
  position:absolute;top:0;bottom:0;left:0;right:-1.1px;
  backface-visibility:hidden;-webkit-backface-visibility:hidden;
  background-repeat:no-repeat;background-size:var(--bw,0px) auto;
}
.face.back{transform:rotateY(180deg)}
.face .sh,.face .gl{
  -webkit-mask-image:linear-gradient(180deg,transparent 0,#000 5.2%,#000 94.8%,transparent 100%);
  mask-image:linear-gradient(180deg,transparent 0,#000 5.2%,#000 94.8%,transparent 100%);
}
.strip.edge .face .sh,.strip.edge .face .gl{
  -webkit-mask-image:linear-gradient(180deg,transparent 0,#000 9%,#000 91%,transparent 100%),var(--hf);
  mask-image:linear-gradient(180deg,transparent 0,#000 9%,#000 91%,transparent 100%),var(--hf);
  -webkit-mask-composite:source-in;mask-composite:intersect;
}
.curl.next .strip.edge .face.front,.curl.prev .strip.edge .face.back{
  --hf:linear-gradient(90deg,#000 0 22%,transparent 96%);
}
.curl.next .strip.edge .face.back,.curl.prev .strip.edge .face.front{
  --hf:linear-gradient(270deg,#000 0 22%,transparent 96%);
}
.face .sh{position:absolute;left:0;right:0;top:var(--pg,21.8%);bottom:var(--pg,21.8%);pointer-events:none}
.curl.next .face.front .sh,.curl.prev .face.back .sh{
  background:linear-gradient(90deg,rgba(58,43,20,var(--a1,0)),rgba(58,43,20,var(--a2,0)));
}
.curl.next .face.back .sh,.curl.prev .face.front .sh{
  background:linear-gradient(90deg,rgba(58,43,20,var(--a2,0)),rgba(58,43,20,var(--a1,0)));
}
.face .gl{
  position:absolute;left:0;right:0;top:var(--pg,21.8%);bottom:var(--pg,21.8%);
  pointer-events:none;background:#fffaf0;
  opacity:calc(var(--shade,0) * var(--lit,1) * var(--lit,1) * .20);
}

/* ---- the loupe: a real magnifier lying on the page.  Pick it up and
       drag it across the book; it stays where you put it. ---- */
.loupe{
  position:absolute;left:0;top:0;
  width:var(--lr,270px);height:var(--lr,270px);
  pointer-events:none;z-index:80;opacity:0;
  transition:opacity .25s ease;
  will-change:transform;
}
.loupe.on{opacity:1}
.loupe.held .ring{cursor:grabbing}
.loupe .ring{
  position:absolute;inset:0;border-radius:50%;
  pointer-events:auto;cursor:grab;
  padding:calc(var(--lr,270px) * .058);
  box-shadow:
    0 1px 2px rgba(58,44,26,.30),
    0 10px 18px rgba(58,44,26,.24),
    0 26px 40px rgba(58,44,26,.20),
    0 48px 66px rgba(58,44,26,.13);
}
/* the bezel is an annulus, so the glass really is see-through */
.loupe .ring:before{
  content:"";position:absolute;inset:0;border-radius:50%;pointer-events:none;
  background:linear-gradient(146deg,
    #fdf7e9 0%,#e6d7b4 14%,#b69d70 32%,#7d6740 50%,
    #cdbb92 66%,#f4ead3 80%,#9b8459 100%);
  box-shadow:
    inset 0 1px 1px rgba(255,255,255,.8),
    inset 0 -2px 3px rgba(70,52,26,.5);
  -webkit-mask-image:radial-gradient(circle closest-side at 50% 50%,transparent 0 88.2%,#000 89.8% 100%);
  mask-image:radial-gradient(circle closest-side at 50% 50%,transparent 0 88.2%,#000 89.8% 100%);
}
/* the handle, drawn before the bezel so the ring covers its inner end */
.loupe .grip{
  position:absolute;left:50%;top:50%;
  width:calc(var(--lr,270px) * .74);height:calc(var(--lr,270px) * .125);
  transform-origin:0 50%;
  transform:rotate(40deg) translate(calc(var(--lr,270px) * .33),-50%);
  border-radius:calc(var(--lr,270px) * .06);
  pointer-events:auto;cursor:grab;
  background:
    linear-gradient(180deg,rgba(255,255,255,.46) 0 13%,rgba(255,255,255,0) 44%,
                    rgba(0,0,0,.26) 100%),
    linear-gradient(90deg,#d9bd82 0 14%,#a9884e 14% 20%,#6d4c2b 20% 62%,
                    #5a3d22 62% 92%,#7a563180 92% 100%);
  box-shadow:0 8px 15px rgba(58,44,26,.26),0 18px 26px rgba(58,44,26,.14);
}
.lens{
  position:relative;display:block;width:100%;height:100%;border-radius:50%;
  background-repeat:no-repeat;overflow:hidden;
  box-shadow:
    inset 0 0 0 1px rgba(52,40,22,.55),
    inset 0 4px 12px rgba(40,30,14,.28),
    inset 0 -7px 16px rgba(255,250,240,.14);
}
.lens .mag{display:none}
/* A second copy of the book, sitting beside the glass outside the tilt, and
   scaled about whichever page point the glass is currently over. */
.zoomwrap{
  position:absolute;inset:0;overflow:hidden;pointer-events:none;z-index:2;
  opacity:0;
}
.zoominner{position:absolute;inset:0;transform-origin:0 0}
.lens:before,.lens:after{content:"";position:absolute;inset:0;border-radius:50%;pointer-events:none}
.lens:before{z-index:1}
.lens:after{z-index:2}
/* the glass bends and darkens toward its rim, with a faint colour fringe */
.lens:before{
  background:radial-gradient(circle at 50% 50%,
    rgba(0,0,0,0) 54%,rgba(58,44,26,.10) 76%,rgba(46,34,16,.34) 100%);
  box-shadow:
    inset 0 0 0 2px rgba(130,162,196,.26),
    inset 0 0 0 4px rgba(206,158,112,.15);
}
/* the dome: one broad specular and a tight crescent opposite it */
.lens:after{
  background:
    radial-gradient(36% 26% at 29% 19%,rgba(255,255,255,.30),rgba(255,255,255,0) 76%),
    radial-gradient(24% 16% at 74% 86%,rgba(255,255,255,.12),rgba(255,255,255,0) 80%),
    linear-gradient(150deg,rgba(255,255,255,.06) 0 18%,rgba(255,255,255,0) 42%);
}

/* ---- controls ---- */
.sb-tools{
  display:flex;align-items:center;gap:6px;
  border:1px solid var(--hairline);border-radius:999px;
  padding:5px 7px;background:rgba(250,246,238,.62);
  -webkit-backdrop-filter:blur(8px);backdrop-filter:blur(8px);
}
.tool{
  width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;
  border:0;border-radius:50%;background:transparent;color:var(--ink-soft);
  cursor:pointer;transition:background-color .18s ease,color .18s ease;
}
.tool:hover{background:rgba(255,252,244,.9);color:var(--ink)}
.tool[aria-pressed="true"]{background:rgba(154,106,62,.16);color:var(--earth)}
.tool:disabled{opacity:.32;cursor:default;background:transparent}
.tool svg{width:15px;height:15px;display:block}
.tool-sep{width:1px;height:17px;background:var(--hairline);margin:0 2px}
.zoom-read{
  font-size:11px;letter-spacing:.1em;color:var(--ink-faint);
  min-width:40px;text-align:center;font-variant-numeric:tabular-nums;
}
@media (pointer:coarse){.loupe{display:none}}

.sb-zone{position:absolute;top:0;bottom:0;border:0;background:transparent;cursor:grab;z-index:60;-webkit-tap-highlight-color:transparent}
.sb-zone:active{cursor:grabbing}
.sb-prev{left:0;width:50%}
.sb-next{right:0;width:50%}

.sb-captions{display:grid;justify-items:center}
.sb-captions>*{grid-area:1/1;margin:0}
.sb-caption{font-size:13px;letter-spacing:var(--track-caps);text-transform:uppercase;color:var(--ink-soft);
  animation:sb-cap-in .5s ease both}
.sb-caption.live{animation:none}
@keyframes sb-cap-in{0%{opacity:0}}
@keyframes sb-cap-out{to{opacity:0}}
.sb-hint{
  margin:0;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--ink-faint);
  transition:opacity .4s ease;
}
.sb-hint.gone{opacity:0}
.sb-wrap.intro .sb-full img,.sb-wrap.intro .sb-half-img{filter:url(#sb-mblur-1)}
.sb-wrap.intro.b2 .sb-full img,.sb-wrap.intro.b2 .sb-half-img{filter:url(#sb-mblur-2)}
.sb-wrap.intro .sb-caption{animation:none}
.sb-wrap.intro .sb-caption.cap-out{display:none}
@media (max-width:640px){
  .hero-kicker{font-size:10.5px;letter-spacing:.16em}
  .sb-wrap{width:100vw;margin-inline:calc(50% - 50vw)}
  .sb-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:70;padding:12px 6px}
  .sb-arrow.left{left:2px}
  .sb-arrow.right{right:2px}
  .sb-3d{max-width:none}
  .sb-hint{font-size:9.5px;letter-spacing:.1em;padding:0 16px;text-align:center}
}

/* ---------------- painted rules + sections ---------------- */
.rule{
  display:block;width:min(1080px,86vw);margin:clamp(30px,6vh,64px) auto;
  height:clamp(26px,4vw,46px);
  background:url(sketchbook/divider.png) center / 100% auto no-repeat;
  opacity:.5;
}
.rule.short{width:min(420px,52vw);opacity:.4}
.section-label{
  font-size:11px;letter-spacing:var(--track-caps);text-transform:uppercase;
  color:var(--ink-faint);margin:0 0 18px;
}
.about{
  position:relative;max-width:1080px;margin:0 auto;
  padding:0 clamp(20px,5vw,48px);
  display:grid;grid-template-columns:minmax(0,1fr) auto;gap:clamp(24px,5vw,60px);align-items:start;
}
.bio{font-size:clamp(17px,1.7vw,20px);line-height:1.74;letter-spacing:.005em;margin:0;font-weight:300;max-width:56ch}
.bio-link{color:var(--ink);text-decoration:underline;text-decoration-color:rgba(43,39,33,.28);
  text-underline-offset:4px;transition:text-decoration-color .2s}
.bio-link:hover{text-decoration-color:var(--ink)}
.bloom{width:clamp(150px,17vw,260px);opacity:.9;user-select:none;align-self:center}
@media (max-width:760px){
  .about{grid-template-columns:1fr}
  .bloom{width:170px;justify-self:center}
}

.contact{max-width:1080px;margin:0 auto;padding:0 clamp(20px,5vw,48px)}
.contact-social{
  margin:20px 0 0;display:flex;flex-wrap:wrap;gap:22px;
  font-size:12px;letter-spacing:var(--track-caps);text-transform:uppercase;
}
.about .bio + .bio{margin-top:1.1em}

.plates{max-width:1080px;margin:0 auto;padding:0 clamp(20px,5vw,48px)}
.plate-list{list-style:none;margin:0;padding:0;border-top:1px solid var(--hairline)}
.plate{
  display:grid;grid-template-columns:3.4em minmax(0,1fr) auto;gap:18px;align-items:baseline;
  width:100%;padding:15px 4px;border:0;border-bottom:1px solid var(--hairline);
  background:transparent;text-align:left;cursor:pointer;color:inherit;
  transition:background-color .22s ease,padding-left .22s ease;
}
.plate:hover,.plate[aria-current="true"]{background:rgba(255,252,244,.5);padding-left:12px}
.plate .n{font-size:12px;color:var(--ink-faint);letter-spacing:var(--track-nav)}
.plate .t{font-family:var(--display);font-size:clamp(19px,2.1vw,26px)}
.plate .p{font-size:12.5px;color:var(--ink-faint);letter-spacing:.08em;text-transform:uppercase;text-align:right}
.plate[aria-current="true"] .p{color:var(--earth)}

.foot{font-size:11.5px;letter-spacing:var(--track-caps);text-transform:uppercase;
  color:var(--ink-faint);text-align:center;margin-top:clamp(48px,7vh,84px);padding-bottom:44px}
</style>
</head>
<body>
<div class="wash" aria-hidden="true"></div>
<main class="page home">

  <header class="top">
    <a class="name" href="#">Meng To</a>
    <nav>
      <a href="#plates">Journal</a>
      <a href="#about">About</a>
      <a href="#contact">Contact</a>
      <div class="top-socials">
        <a href="https://x.com/MengTo" target="_blank" rel="me noopener" class="icon-btn" aria-label="X"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.7 2.6h3.3l-7.2 8.2 8.5 11.2h-6.7l-5.2-6.9-6 6.9H1.1l7.7-8.8L.7 2.6h6.9l4.7 6.3 5.4-6.3Zm-1.2 17.5h1.8L7.6 4.4H5.7l10.8 15.7Z"/></svg></a>
        <a href="https://www.linkedin.com/in/mengto" target="_blank" rel="me noopener" class="icon-btn" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M4.9 3.5a2.1 2.1 0 1 1 0 4.2 2.1 2.1 0 0 1 0-4.2ZM3.1 9.3h3.6v11.6H3.1V9.3Zm6 0h3.4v1.6h.05c.48-.9 1.65-1.85 3.4-1.85 3.63 0 4.3 2.35 4.3 5.4v6.45h-3.6v-5.72c0-1.36-.02-3.12-1.92-3.12-1.92 0-2.22 1.48-2.22 3.02v5.82H9.1V9.3Z"/></svg></a>
        <a href="https://www.instagram.com/mengto" target="_blank" rel="me noopener" class="icon-btn" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="2.6" y="2.6" width="18.8" height="18.8" rx="5.4"/><circle cx="12" cy="12" r="4.4"/><circle cx="17.6" cy="6.4" r="1.15" fill="currentColor" stroke="none"/></svg></a>
        <a href="mailto:meng@designcode.io" class="icon-btn" aria-label="Email"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><rect x="2.4" y="4.6" width="19.2" height="14.8" rx="2.4"/><path d="m3.2 6.4 8.8 6.6 8.8-6.6"/></svg></a>
      </div>
    </nav>
  </header>

  <section id="sketchbook" class="hero">
    <img class="botany l" src="sketchbook/botany-left.png" alt="" aria-hidden="true">
    <img class="botany r" src="sketchbook/botany-right.png" alt="" aria-hidden="true">

    <p class="hero-kicker">Designer / Creator / AI Educator / Founder @ Singapore</p>

    <div class="sb-wrap" id="sbWrap">
      <svg width="0" height="0" style="position:absolute" aria-hidden="true">
        <filter id="sb-mblur-1"><feGaussianBlur stdDeviation="5 0"/></filter>
        <filter id="sb-mblur-2"><feGaussianBlur stdDeviation="14 0"/></filter>
      </svg>
      <div class="sb-stage" id="sbStage">
        <button class="sb-arrow left" id="sbLeft" aria-label="previous page">
          <svg viewBox="0 0 14 44" width="14" height="44" fill="none" aria-hidden="true"><polyline points="11,3 3,22 11,41" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <div class="sb-3d" id="sb3d">
          <div class="sb-tilt" id="sbTilt">
            <div class="sb-cast ambient" aria-hidden="true"></div>
            <div class="sb-cast contact" aria-hidden="true"></div>
            <div class="sb-cast hair" aria-hidden="true"></div>
            <div class="sb-book" id="sbBook"></div>
          </div>
          <div class="zoomwrap" id="zoomWrap" aria-hidden="true"><div class="zoominner" id="zoomInner"></div></div>
          <div class="loupe" id="loupe"><span class="grip"></span><span class="ring"><span class="lens" id="loupeLens"><span class="mag" id="loupeMag"></span></span></span></div>
        </div>
        <button class="sb-arrow right" id="sbRight" aria-label="next page">
          <svg viewBox="0 0 14 44" width="14" height="44" fill="none" aria-hidden="true"><polyline points="3,3 11,22 3,41" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
      </div>
      <div class="sb-captions" id="sbCaptions"></div>
      <div class="sb-tools" role="group" aria-label="view controls">
        <button class="tool" id="zOut" aria-label="zoom out"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="8.6" cy="8.6" r="5.6"/><path d="M12.8 12.8 17.4 17.4M6.2 8.6h4.8"/></svg></button>
        <span class="zoom-read" id="zRead">100%</span>
        <button class="tool" id="zIn" aria-label="zoom in"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="8.6" cy="8.6" r="5.6"/><path d="M12.8 12.8 17.4 17.4M6.2 8.6h4.8M8.6 6.2v4.8"/></svg></button>
        <span class="tool-sep" aria-hidden="true"></span>
        <button class="tool" id="loupeBtn" aria-label="magnifier" aria-pressed="true"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="8.8" cy="8.8" r="5.8"/><path d="M13 13l4.4 4.4"/><path d="M6.4 7.2a3.2 3.2 0 0 1 2.4-1.4" opacity=".55"/></svg></button>
      </div>
      <p class="sb-hint" id="sbHint">Drag the page to turn · Drag the glass across it</p>
    </div>

    <button class="hero-down" id="heroDown" aria-label="scroll to about">
      <svg viewBox="0 0 44 22" width="34" height="17" fill="none" aria-hidden="true">
        <polyline points="3,3 22,11 41,3" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/>
        <polyline points="3,11 22,19 41,11" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </button>
  </section>

  <div class="rule" aria-hidden="true"></div>

  <section id="about" class="about">
    <div>
      <p class="section-label">About</p>
      <p class="bio">Meng To is a designer and teacher in Singapore. He founded <a class="bio-link" href="https://designcode.io" target="_blank" rel="noopener">Design+Code</a>, where he teaches designers code and developers design, and builds <a class="bio-link" href="https://aura.build" target="_blank" rel="noopener">Aura</a> and <a class="bio-link" href="https://dreamcut.ai" target="_blank" rel="noopener">DreamCut</a>.</p>
      <p class="bio">This sketchbook is the slower half of that. The city looked at properly, in ink and a little colour: shophouse shutters, hawker tents, the bay at dusk.</p>
    </div>
    <img class="bloom" src="sketchbook/bloom.png" alt="" aria-hidden="true">
  </section>

  <div class="rule short" aria-hidden="true"></div>

  <section id="plates" class="plates">
    <p class="section-label">Plates</p>
    <ol class="plate-list" id="plateList"></ol>
  </section>

  <div class="rule short" aria-hidden="true"></div>

  <section id="contact" class="contact">
    <p class="section-label">Contact</p>
    <p class="bio">Write to me at <a class="bio-link" href="mailto:meng@designcode.io">meng@designcode.io</a>. I read everything, and I answer most of it.</p>
    <p class="contact-social">
      <a class="bio-link" href="https://x.com/MengTo" target="_blank" rel="me noopener">X</a>
      <a class="bio-link" href="https://www.linkedin.com/in/mengto" target="_blank" rel="me noopener">LinkedIn</a>
      <a class="bio-link" href="https://www.instagram.com/mengto" target="_blank" rel="me noopener">Instagram</a>
    </p>
  </section>

  <p class="foot">Singapore · Sketchbook</p>
</main>

<script>
/* =====================================================================
   Meng To — sketchbook hero.
   Spreads are transparent PNGs of an open sketchbook generated with
   Higgsfield.  The leaf that turns is a real curved surface: a chain of
   nested strips whose tangent sweeps through an arc, so the page bends
   the way paper bends instead of pivoting like a flat door.
   ===================================================================== */
const Q=new URLSearchParams(location.search);
const DIR='sketchbook/';
const PAGES=[
  {file:'marina-bay-sands.png',   title:'Marina Bay Sands',          place:'Bayfront'},
  {file:'gardens-by-the-bay.png', title:'Gardens by the Bay',        place:'Supertree Grove'},
  {file:'merlion.png',            title:'The Merlion',               place:'Merlion Park'},
  {file:'buddha-tooth.png',       title:'Buddha Tooth Relic Temple', place:'Chinatown'},
  {file:'joo-chiat.png',          title:'Joo Chiat Shophouses',      place:'Katong'},
  {file:'lau-pa-sat.png',         title:'Lau Pa Sat',                place:'Raffles Quay'},
  {file:'marina-bay-skyline.png', title:'Marina Bay Skyline',        place:'The Bay'},
  {file:'singapore-river.png',    title:'Singapore River',           place:'Boat Quay'},
  {file:'botanic-gardens.png',    title:'Botanic Gardens',           place:'Tanglin'}
];
PAGES.forEach(p=>p.url=DIR+p.file);
const M=PAGES.length, LAND=6;

const wrap=document.getElementById('sbWrap');
const stage=document.getElementById('sbStage');
const sb3d=document.getElementById('sb3d');
const book=document.getElementById('sbBook');
const capBox=document.getElementById('sbCaptions');
const hint=document.getElementById('sbHint');
const REDUCED=matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ------------------------------------------------ the turning leaf */
const N=18;            /* strips — enough for a smooth curve          */
const SPAN=0.449;      /* gutter → outer page edge, as a fraction     */
const BETA=0.60;       /* peak curl of the arc, radians              */
let idx=0, turn=null;  /* turn = {dir, from, to, t}                   */
let strips=[];         /* the chain, kept for per-frame lighting       */

function el(t,c){const e=document.createElement(t);if(c)e.className=c;return e}
function imgEl(i,side){
  const im=new Image();im.className='sb-half-img '+side;
  im.draggable=false;im.alt='';im.src=PAGES[i].url;return im;
}

function halfEl(pos,i){
  const d=el('div','sb-half '+pos);
  d.appendChild(imgEl(i,pos));
  d.appendChild(el('div','gutter-shade '+pos));
  return d;
}
/* build the strip chain once per turn; background offsets are pure
   geometry, so they never need touching again while it animates */
function buildCurl(dir,from,to){
  strips=[];
  const c=el('div','curl '+dir);
  c.style.setProperty('--n',N);
  c.style.setProperty('--span',SPAN);
  let host=c;
  for(let i=0;i<N;i++){
    const s=el('div','strip');
    s.style.setProperty('--i',i);
    const gut='calc(var(--bw) * 0.5)';
    const sw='calc(var(--bw) * '+SPAN+' / '+N+')';
    const A='calc(-1 * ('+gut+' + '+i+' * '+sw+'))';         /* faces the from-page  */
    const B='calc('+(i+1)+' * '+sw+' - '+gut+')';            /* faces the to-page    */
    const f=el('div','face front'), b=el('div','face back');
    const dress=(e,url,px)=>{
      e.style.backgroundImage='url('+url+')';
      e.style.backgroundPositionX=px;
    };
    dress(f,PAGES[from].url, dir==='next'?A:B);
    dress(b,PAGES[to].url,   dir==='next'?B:A);
    f.appendChild(el('div','sh'));f.appendChild(el('div','gl'));
    b.appendChild(el('div','sh'));b.appendChild(el('div','gl'));
    s.appendChild(f);s.appendChild(b);
    if(i===N-1)s.classList.add('edge');
    host.appendChild(s);host=s;
    strips.push(s);
  }
  return c;
}
function applyTurn(t){
  const th=Math.PI*t;                       /* how far the leaf has swung */
  const beta=BETA*Math.sin(Math.PI*t);      /* it is flat at both ends    */
  const D=180/Math.PI;
  const tt=th+beta, td=2*beta/N;
  sb3d.style.setProperty('--tt',(tt*D).toFixed(2)+'deg');
  sb3d.style.setProperty('--td',(td*D).toFixed(3)+'deg');
  sb3d.style.setProperty('--shade',Math.sin(Math.PI*t).toFixed(3));
  fadeCaption(t);
  for(let i=0;i<strips.length;i++){
    const l1=Math.abs(Math.cos(tt-i*td));        /* facing at this strip's near edge */
    const l2=Math.abs(Math.cos(tt-(i+1)*td));    /* ...and at its far edge           */
    const st=strips[i].style;
    st.setProperty('--lit',l1.toFixed(3));
    st.setProperty('--a1',((1-l1)*.62).toFixed(3));
    st.setProperty('--a2',((1-l2)*.62).toFixed(3));
  }
}
function paint(){
  book.textContent='';
  if(!turn){
    const f=el('div','sb-full');
    const im=new Image();im.src=PAGES[idx].url;im.alt=PAGES[idx].title;
    im.draggable=false;
    f.appendChild(im);book.appendChild(f);
    sb3d.style.setProperty('--shade','0');
  }else{
    const next=turn.dir==='next';
    book.appendChild(halfEl('left', next?turn.from:turn.to));
    book.appendChild(halfEl('right',next?turn.to:turn.from));
    book.appendChild(buildCurl(turn.dir,turn.from,turn.to));
    applyTurn(turn.t);
  }
  const a=el('button','sb-zone sb-prev'),b=el('button','sb-zone sb-next');
  a.setAttribute('aria-label','previous page');b.setAttribute('aria-label','next page');
  book.appendChild(a);book.appendChild(b);
  layout();
  caption();
  marks();
  if(typeof syncZoomLayer==='function')syncZoomLayer();
  if(typeof placeLoupe==='function')placeLoupe();
}
function caption(){
  capBox.textContent='';
  capOut=capIn=null;
  if(turn){
    capOut=el('p','sb-caption live');capOut.textContent=PAGES[turn.from].title;capBox.appendChild(capOut);
    capIn=el('p','sb-caption live');capIn.textContent=PAGES[turn.to].title;capBox.appendChild(capIn);
    fadeCaption(turn.t);
  }else{
    const p=el('p','sb-caption');p.textContent=PAGES[idx].title;capBox.appendChild(p);
  }
}
let capOut=null,capIn=null;
function fadeCaption(t){
  if(!capOut||!capIn)return;
  /* the old title is gone before the new one arrives, so they never
     sit on top of each other mid-drag */
  const out=1-Math.max(0,Math.min(1,(t-0.10)/0.28));
  const inn=Math.max(0,Math.min(1,(t-0.56)/0.30));
  capOut.style.opacity=out.toFixed(3);
  capIn.style.opacity=inn.toFixed(3);
}
function layout(){
  sb3d.style.setProperty('--bw',book.clientWidth+'px');
}
addEventListener('resize',layout);

/* ------------------------------------------------------ spring loop */
let spring=null;
function animateTo(target,onDone,stiff,damp){
  spring={kind:'spring',v:0,target:target,done:onDone,k:stiff||150,c:damp||22};
  kick();
}
/* the riffle wants a fixed tempo, not a spring settling time */
function tweenTo(target,dur,onDone){
  spring={kind:'tween',from:turn?turn.t:0,target:target,dur:dur,e:0,done:onDone};
  kick();
}
let raf=null,last=0;
function tick(now){
  raf=null;
  const dt=Math.min(0.032,(now-last)/1000||0.016);last=now;
  if(spring&&turn){
    const s=spring;
    if(s.kind==='tween'){
      s.e+=dt;
      const k=Math.min(1,s.e/s.dur);
      turn.t=s.from+(s.target-s.from)*k;
      applyTurn(turn.t);
      if(k>=1){spring=null;const d=s.done;d&&d();}
    }else{
      const x=turn.t-s.target;
      s.v+= (-s.k*x - s.c*s.v)*dt;
      turn.t+=s.v*dt;
      if(Math.abs(turn.t-s.target)<0.002&&Math.abs(s.v)<0.02){
        turn.t=s.target;spring=null;
        applyTurn(turn.t);
        const d=s.done;d&&d();
      }else applyTurn(turn.t);
    }
  }
  viewSpring();
  const lmoved=loupeEase();
  /* kick() may already have queued the next frame from a done-callback */
  if((spring||viewActive||lmoved)&&raf===null) raf=requestAnimationFrame(tick);
}
function kick(){ if(raf===null){last=performance.now();raf=requestAnimationFrame(tick);} }

/* ------------------------------------------- tilt + zoom of the book */
const TILT_X=4.5, TILT_Y=7;      /* degrees — deliberately restrained   */
const ZOOM_MIN=0.9, ZOOM_MAX=1.5;
const view={rx:0,ry:0,z:1, trx:0,try_:0,tz:1};
let viewActive=false;
let lastZ=1;
function applyView(){
  sb3d.style.setProperty('--rx',view.rx.toFixed(2)+'deg');
  sb3d.style.setProperty('--ry',view.ry.toFixed(2)+'deg');
  sb3d.style.setProperty('--zoom',view.z.toFixed(3));
  /* the glass stays put, but the page under it has moved */
  if(view.z!==lastZ){lastZ=view.z;if(typeof placeLoupe==='function')placeLoupe();}
}
function viewSpring(){
  const e=0.14;
  let moved=false;
  for(const [k,t] of [['rx','trx'],['ry','try_'],['z','tz']]){
    const d=view[t]-view[k];
    if(Math.abs(d)>0.0006){view[k]+=d*e;moved=true;}
    else view[k]=view[t];
  }
  if(moved)applyView();
  viewActive=moved;
  return moved;
}
function setView(rx,ry,z){
  view.trx=Math.max(-TILT_X,Math.min(TILT_X,rx));
  view.try_=Math.max(-TILT_Y,Math.min(TILT_Y,ry));
  view.tz=Math.max(ZOOM_MIN,Math.min(ZOOM_MAX,z));
  viewActive=true;kick();
  if(typeof syncZoom==='function')syncZoom();
}
/* the book leans toward the cursor — no dragging, and never far */
function tiltTo(cx,cy){
  if(drag)return;                       /* hold still while a page is being turned */
  const r=book.getBoundingClientRect();
  if(!r.width)return;
  const nx=Math.max(-1,Math.min(1,(cx-(r.left+r.width/2))/(r.width*0.62)));
  const ny=Math.max(-1,Math.min(1,(cy-(r.top+r.height/2))/(r.height*0.9)));
  setView(-ny*TILT_X, nx*TILT_Y, view.tz);
}
addEventListener('pointermove',e=>{
  if(e.pointerType==='touch')return;
  tiltTo(e.clientX,e.clientY);
},{passive:true});
addEventListener('pointerout',e=>{if(!e.relatedTarget)setView(0,0,view.tz)});
addEventListener('blur',()=>setView(0,0,view.tz));
/* the wheel belongs to the page — zoom is on the toolbar, or a double click
   to come back to 100% */
stage.addEventListener('dblclick',()=>setView(view.trx,view.try_,1));

/* ------------------------------------------------------- pointer work */
let drag=null;
function bookRect(){return book.getBoundingClientRect()}
function hideHint(){hint.classList.add('gone')}

stage.addEventListener('pointerdown',e=>{
  if(e.button!==0)return;
  e.preventDefault();                     /* no text selection, no image drag */
  const onBook=e.target.closest('.sb-zone');
  stage.setPointerCapture(e.pointerId);
  hideHint();
  if(!onBook||introOn)return;
  const r=bookRect();
  const dir=(e.clientX-r.left)/r.width>0.5?'next':'prev';
  startTurn(dir,0);
  drag={dir:dir,x0:e.clientX,w:r.width,moved:0,vel:0,tPrev:performance.now()};
});
stage.addEventListener('pointermove',e=>{
  if(!drag)return;
  const dx=e.clientX-drag.x0;
  drag.moved=Math.max(drag.moved,Math.abs(dx));
  const raw=(drag.dir==='next'? -dx : dx)/(drag.w*0.62);
  const t=Math.max(0,Math.min(1,raw));
  const now=performance.now();
  drag.vel=(t-(turn?turn.t:0))/Math.max(0.001,(now-drag.tPrev)/1000);
  drag.tPrev=now;
  if(turn){turn.t=t;applyTurn(t);}
});
function endDrag(e){
  if(!drag)return;
  const d=drag;drag=null;
  if(!turn)return;
  if(d.moved<6){                              /* a tap, not a drag */
    commit();return;
  }
  const go = turn.t>0.42 || d.vel>1.1;
  if(go)commit(); else cancel();
}
stage.addEventListener('dragstart',e=>e.preventDefault());
stage.addEventListener('selectstart',e=>e.preventDefault());
stage.addEventListener('pointerup',endDrag);
stage.addEventListener('pointercancel',endDrag);

/* ------------------------------------------------------ turn control */
function startTurn(dir,t){
  spring=null;
  if(turn){idx=turn.to;turn=null;}      /* settle anything still in flight */
  if(typeof shoveLoupe==='function')shoveLoupe(dir);
  const from=idx;
  turn={dir:dir,from:from,to:dir==='next'?(from+1)%M:(from-1+M)%M,t:t||0};
  paint();
}
function commit(){
  if(!turn)return;
  if(REDUCED){idx=turn.to;turn=null;paint();return;}
  animateTo(1,()=>{idx=turn.to;turn=null;paint();},170,26);
  kick();
}
function cancel(){
  if(!turn)return;
  animateTo(0,()=>{turn=null;paint();},150,24);
  kick();
}
function step(dir){
  if(introOn)endIntro();
  if(turn){ /* finish whatever is in flight first */ idx=turn.to;turn=null; }
  startTurn(dir,0);commit();
}
function goTo(i){
  if(introOn)endIntro();
  if(i===idx)return;
  if(turn){idx=turn.to;turn=null;}
  const fwd=(i-idx+M)%M, back=(idx-i+M)%M;
  if(Math.min(fwd,back)===1){step(fwd===1?'next':'prev');return;}
  idx=i;paint();
}
document.getElementById('sbLeft').onclick=()=>step('prev');
document.getElementById('sbRight').onclick=()=>step('next');
addEventListener('keydown',e=>{
  if(e.key!=='ArrowLeft'&&e.key!=='ArrowRight')return;
  if(e.metaKey||e.ctrlKey||e.altKey)return;
  const t=e.target;
  if(t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.isContentEditable))return;
  e.preventDefault();hideHint();
  step(e.key==='ArrowRight'?'next':'prev');
});
document.getElementById('heroDown').onclick=()=>{
  document.getElementById('about').scrollIntoView({behavior:'smooth',block:'start'});
};

/* --------------------------------------------------- loupe + controls */
const loupe=document.getElementById('loupe');
const lens=document.getElementById('loupeLens');
const mag=document.getElementById('loupeMag');
const zRead=document.getElementById('zRead');
const loupeBtn=document.getElementById('loupeBtn');
const zInBtn=document.getElementById('zIn'), zOutBtn=document.getElementById('zOut');
const MAG=2.3;
const DESK=getComputedStyle(document.documentElement).getPropertyValue('--paper').trim()||'#ece7dc';
let loupeOn=true, lx=null, ly=null, lgrab=null, lTarget=null;

function loupeSize(){return Math.round(Math.max(165,Math.min(262,book.clientWidth*0.235)));}
/* the loupe's own coordinate space: stage pixels in live mode (it sits
   outside the book's transform), book pixels otherwise */
function bookBox(){
  return {x:0,y:0,w:book.clientWidth,h:book.clientHeight};
}
/* park it on the desk at the lower right, half off the book */
function restLoupe(){
  const b=bookBox();
  lx=b.x+b.w*0.88; ly=b.y+b.h*0.855;
  placeLoupe();
}
/* The glass sits above the tilt, in the book's untransformed pixels, so the
   lean of the page never nudges it.  What the tilt does change is which part
   of the paper is under the glass, and only the scale matters enough to
   correct for: the book is drawn about its own centre. */
const zoomWrap=document.getElementById('zoomWrap');
const zoomInner=document.getElementById('zoomInner');
/* mirror whatever the book is currently showing into the magnified copy */
function syncZoomLayer(){
  zoomInner.textContent='';
  for(const c of book.children){
    if(c.classList.contains('sb-zone'))continue;      /* hit targets need no copy */
    zoomInner.appendChild(c.cloneNode(true));
  }
}
function placeLoupe(){
  if(lx===null)return;
  const B=bookBox(), bw=B.w, bh=B.h;
  if(!bw)return;
  const R=loupeSize()/2, bez=R*2*0.058;
  loupe.style.setProperty('--lr',R*2+'px');
  loupe.style.transform='translate3d('+(lx-R).toFixed(1)+'px,'+(ly-R).toFixed(1)+'px,0)';
  if(loupeOn)loupe.classList.add('on');

  /* where the paper's edges actually land once the book is scaled */
  const z=view.z, cx=bw/2, cy=bh/2;
  const x0=cx+(bw*.051-cx)*z, x1=cx+(bw*.949-cx)*z;
  const y0=cy+(bh*.218-cy)*z, y1=cy+(bh*.782-cy)*z;
  /* How far the glass's own centre is inside the paper.  The copy fades out
     as it wanders off the sheet, so you are left looking through plain
     glass rather than at a sliver of page on flat desk. */
  const nx=Math.max(x0,Math.min(lx,x1));
  const ny=Math.max(y0,Math.min(ly,y1));
  const inside=(lx>x0&&lx<x1&&ly>y0&&ly<y1)
    ? Math.min(lx-x0, x1-lx, ly-y0, y1-ly)
    : -Math.hypot(lx-nx,ly-ny);
  const k=Math.max(0,Math.min(1,(inside+R*0.30)/(R*0.55)));

  zoomWrap.style.opacity=(loupeOn?k:0).toFixed(3);
  if(k<=0.002)return;
  const r=(R-bez).toFixed(1);
  const mask='radial-gradient(circle '+r+'px at '+lx.toFixed(1)+'px '+ly.toFixed(1)+'px,'
    +'#000 calc(100% - 1px),transparent 100%)';
  zoomWrap.style.webkitMaskImage=mask;
  zoomWrap.style.maskImage=mask;
  /* the page point beneath the glass, magnified about that same spot so the
     lens keeps showing MAG times whatever is on screen */
  const px=cx+(lx-cx)/z, py=cy+(ly-cy)/z, s=MAG*z;
  zoomInner.style.transform='translate('+(lx-px*s).toFixed(1)+'px,'+(ly-py*s).toFixed(1)+'px) '
    +'scale('+s.toFixed(4)+')';
}
/* the leaf shoves the glass aside as it sweeps past */
function shoveLoupe(dir){
  if(!loupeOn||lx===null||lgrab)return;
  const b=bookBox();
  /* which page point the glass covers, once the book's scale is undone */
  const nx=(b.w/2+(lx-b.x-b.w/2)/view.z)/b.w, ny=(b.h/2+(ly-b.y-b.h/2)/view.z)/b.h;
  if(nx<0.02||nx>0.98||ny<0.17||ny>0.83)return;      /* already clear of the page */
  lTarget={x:b.x+b.w*(dir==='next'?0.12:0.88), y:b.y+b.h*0.855};
  kick();
}
function loupeEase(){
  if(!lTarget)return false;
  if(lgrab){lTarget=null;return false;}
  const dx=lTarget.x-lx, dy=lTarget.y-ly;
  if(Math.abs(dx)<0.5&&Math.abs(dy)<0.5){lx=lTarget.x;ly=lTarget.y;lTarget=null;placeLoupe();return false;}
  lx+=dx*0.17;ly+=dy*0.17;placeLoupe();
  return true;
}
loupe.addEventListener('pointerdown',e=>{
  if(!loupeOn||e.button!==0)return;
  e.preventDefault();e.stopPropagation();     /* never starts a page turn */
  lTarget=null;
  lgrab={cx:e.clientX,cy:e.clientY,lx0:lx,ly0:ly};
  loupe.classList.add('held');
  loupe.setPointerCapture(e.pointerId);
  hideHint();
});
loupe.addEventListener('pointermove',e=>{
  if(!lgrab)return;
  const b=bookBox(), R=loupeSize()/2;
  /* the glass carries none of the book's transform, so the cursor maps 1:1 */
  lx=Math.max(b.x-R*0.7,Math.min(b.x+b.w+R*0.7, lgrab.lx0+(e.clientX-lgrab.cx)));
  ly=Math.max(b.y-R*0.7,Math.min(b.y+b.h+R*1.0, lgrab.ly0+(e.clientY-lgrab.cy)));
  placeLoupe();
});
function dropLoupe(){lgrab=null;loupe.classList.remove('held');}
loupe.addEventListener('pointerup',dropLoupe);
loupe.addEventListener('pointercancel',dropLoupe);
loupeBtn.onclick=()=>{
  loupeOn=!loupeOn;
  loupeBtn.setAttribute('aria-pressed',String(loupeOn));
  loupe.classList.toggle('on',loupeOn);
  if(loupeOn&&lx===null)restLoupe();
};
addEventListener('resize',()=>{lx=null;restLoupe();});

function syncZoom(){
  zRead.textContent=Math.round(view.tz*100)+'%';
  zOutBtn.disabled=view.tz<=ZOOM_MIN+0.001;
  zInBtn.disabled=view.tz>=ZOOM_MAX-0.001;
}
zInBtn.onclick=()=>{setView(view.trx,view.try_,view.tz*1.16);hideHint();};
zOutBtn.onclick=()=>{setView(view.trx,view.try_,view.tz/1.16);hideHint();};

/* --------------------------------------------------------- the index */
const plateList=document.getElementById('plateList');
PAGES.forEach((p,i)=>{
  const li=el('li');
  const b=el('button','plate');
  b.innerHTML='<span class="n">'+String(i+1).padStart(2,'0')+'</span>'+
              '<span class="t"></span><span class="p"></span>';
  b.querySelector('.t').textContent=p.title;
  b.querySelector('.p').textContent=p.place;
  b.onclick=()=>{goTo(i);document.getElementById('sketchbook').scrollIntoView({behavior:'smooth',block:'center'});};
  li.appendChild(b);plateList.appendChild(li);
});
function marks(){
  const cur=turn?turn.to:idx;
  plateList.querySelectorAll('.plate').forEach((b,i)=>b.setAttribute('aria-current',i===cur?'true':'false'));
}

/* ---------------------------------------------------------- the riffle */
let riffle=null,riffleAt=0,introOn=false;
function endIntro(){
  introOn=false;wrap.classList.remove('intro','b2');
}
function riffleStep(){
  const s=riffle[riffleAt];
  wrap.classList.toggle('b2',s.bell>0.55);
  startTurn('next',0);
  tweenTo(1,s.dur,()=>{
    idx=turn.to;turn=null;
    riffleAt++;
    if(introOn&&riffleAt<riffle.length){paint();riffleStep();}
    else{endIntro();paint();}
  });
}
function startIntro(){
  const coarse=matchMedia('(max-width: 640px), (pointer: coarse)').matches;
  if(coarse||REDUCED||Q.has('nointro')){idx=LAND;paint();return;}
  const steps=M+LAND;
  riffle=[];
  for(let r=0;r<steps;r++){
    const bell=Math.sin(Math.PI*(r/(steps-1)));
    riffle.push({bell:bell,dur:0.26-0.19*bell});
  }
  riffleAt=0;introOn=true;wrap.classList.add('intro');
  riffleStep();
}

/* ------------------------------------------------------------- boot */
(async function boot(){
  idx=Q.has('shot')?(parseInt(Q.get('shot'),10)||0)%M:0;
  paint();applyView();
  await Promise.all(PAGES.map(p=>{
    const im=new Image();im.src=p.url;
    return im.decode?im.decode().catch(()=>{}):new Promise(r=>{im.onload=im.onerror=r});
  }));
  if(document.fonts&&document.fonts.ready)await document.fonts.ready.catch(()=>{});
  syncZoom();restLoupe();
  document.body.dataset.ready='1';
  if(Q.has('shot')){
    if(Q.has('t')){startTurn(Q.get('dir')||'next',parseFloat(Q.get('t')));}
    return;
  }
  setTimeout(startIntro,220);
})();
<\/script>
</body>
</html>
`, a = `<style id="threeui-sketchbook-host">
html,body,.page{width:100%;height:100%;min-height:0;overflow:hidden}
body>.wash{display:block}
.page>.top,.page>.rule,.page>.about,.page>.plates,.page>.contact,.page>.foot{display:none!important}
#sketchbook{width:100%;height:100%;min-height:0;padding:12px 0 10px;align-content:center}
#sketchbook>.botany,#sketchbook>.hero-kicker,#sketchbook>.hero-down{display:none!important}
#sketchbook .sb-wrap{gap:8px}
#sketchbook .sb-3d{max-width:min(900px,92vw)}
#sketchbook .sb-captions{min-height:18px}
@media(max-width:640px){#sketchbook{padding:4px 0}#sketchbook .sb-wrap{gap:5px}#sketchbook .sb-3d{max-width:100vw}}
</style>`;
function r(n = "/sketchbook/") {
  const e = n.endsWith("/") ? n : `${n}/`;
  return t.replaceAll("sketchbook/", e).replace("</head>", `${a}</head>`);
}
export {
  t as CANONICAL_SKETCHBOOK_HTML,
  r as createSketchbookDocument
};
